require('dotenv').config()

const path = require('path');
const socketServer = require('./socket');

const WebSocket = require('ws');

const { PORT : port } = process.env;
const Http = require('http')
const express = require('express');

const app = new express();

app.engine('html', require('ejs').renderFile);

// 테스트 툴 렌더링 / localhost:3000으로 접속하면 테스트 툴 사용 가능 

app.get('/', (req, res) => {
  res.render(path.join(__dirname, 'public', 'index.html'));
})

// 서버 열기
const server = Http.createServer(app);

// 웹소켓 서버를 연 서버에 담
const wss = new WebSocket.Server({ server });

socketServer.start(wss);

// 서버 listening
server.listen(port, () => {
  console.log(`Server is Running on port ${port}`);
})