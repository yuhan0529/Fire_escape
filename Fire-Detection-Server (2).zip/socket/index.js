
// 연결된 디바이스들을 담아두는 배열
const devices = []

exports.start = (wss) => {
  wss.on('connection', (ws) => {
    console.log('Client is Connected');

    // 연결 되면 devices 배열에 추가
    devices.push(ws);

    // 디바이스에서 화재가 감지되었을 때
    ws.on('message', (alert) => {
      try {
        let path;

        const value = alert.toUpperCase().split('-');
      
        console.log(value);

        if (value[0] === 'INFRA') {
			
		    //Request Example : 형식 : INFRA-DETECTED  값 : infra-D-1 

          console.log("INFRA 이벤트");

          const detected = value[1]
          const flag = value[2]

          let newPath;

          switch (detected) {
            case 'D':
              newPath = 'F';
              break;
            case 'F':
              newPath = 'D';
              break;
            default:
              throw error
          }

          // Response는 Flag-Location구조  0은 감지 안됨, 1은 감지됨 ex) 2 1 e
          // 연결된 모든 디바이스들에게 path 보냄
          devices.forEach((device) => {
            device.send("2 "+ newPath + flag);
          });

        } else if (value[0] === 'FIRE') {

          const location = value[1]

		      //Request Example : 형식 : FIRE-LOCATION 값 :  fire-f, 끝나면 fire-done
		
          console.log("FIRE 이벤트");

          // Path의 종류는 /로 구분, 경로는 - 로 구분. 화재 종료시 DONE 서버에 보내야댐 ex) 1 D BF : D로가는 경로 / B에서 F로 간 후 탈출하는 경로
          // 어디서 불이 났는지 확인 후 path에 탈출구 지정
          switch(location) {
            case 'B':
              path = 'D  '
              break;
            case 'C':
              path = 'DBF'
              break;
            case 'D':
              path = 'BF '
              break;
            case 'E':
              path = 'DBF'
              break;
            case 'F':
              path = 'D  '
              break;
            case 'X':
              path = 'X '
              break;
            default:
              throw error
          }
		  
		  console.log("path : "+path);

          // 연결된 모든 디바이스들에게 path 보냄
		  
		  devices.forEach((device) => {
            device.send("3"+location+"  ");
          });
		  
          devices.forEach((device) => {
            device.send("1"+path);
          });
		  
        }

      } catch (error) {
        console.log("ERROR : "+error.message);
        ws.send("0"+error.message);
      }
    })

    // 디바이스의 웹소켓이 close 되었을 때
    ws.on('close', () => {
      //devices에서 close된 디바이스 삭제
      devices.splice(devices.indexOf(ws),1);
      console.log('Client is Disconnected');
    })

  })
} 